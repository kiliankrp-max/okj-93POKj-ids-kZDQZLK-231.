"""Deciding whether a listing is worth telling you about.

Vinted's own filters get you most of the way there; these cover what its search cannot.
The important one is price: Vinted filters on the asking price, but you pay the asking
price plus buyer protection, so a `price_to=30` search happily returns things that cost you
33. Filtering on the total is the difference between a useful alert and a misleading one.

The checks come in three tiers, by what they cost:

* `Rules.check` needs only the listing: words, patterns, prices, condition, the blocklist.
* `check_seller` needs the seller's member page (country, rating), which costs a request
  the first time, so it only runs for listings that passed everything cheaper.
* `check_deal` needs the search's typical price, which the poller reads once per check.

Every rejection carries a reason and a sentence, because a search that stays quiet should
be able to say why.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal

from vinted_bot.db.repo import Query
from vinted_bot.deals import deal_percent, site_currency
from vinted_bot.engine.rates import convert
from vinted_bot.engine.validation import TITLE_REGEX_FLAGS, fold
from vinted_bot.vinted.models import Item, SellerProfile

# Vinted's own rating is a fraction; people think in stars.
_STARS = 5


@dataclass(frozen=True, slots=True)
class Rejection:
    """Why a listing was skipped. Worth keeping around: it is what makes a quiet search
    explainable rather than suspicious."""

    reason: str
    detail: str


# Straight and typographic double quotes: phones type the second kind.
_QUOTES = '"\u201c\u201d\u201e'


def _word_pattern(term: str, *, prefix: bool = False) -> re.Pattern[str] | None:
    """Match a word or phrase starting at a word boundary.

    With `prefix` it matches the start of a word, so "jean" finds "Jeans"; without it,
    only the whole word, so "art" never excludes "smartphone" or "party". A trailing *
    asks for a prefix match and quotes ("jean") for the whole word, whatever the
    default. Text is folded first, so case and accents never matter.
    """
    folded = fold(term.strip())
    if len(folded) > 1 and folded[0] in _QUOTES and folded[-1] in _QUOTES:
        folded, prefix = folded[1:-1].strip(), False
    if folded.endswith("*"):
        folded, prefix = folded.rstrip("*").strip(), True
    if not folded:
        return None
    tail = "" if prefix else r"(?!\w)"
    return re.compile(rf"(?<!\w){re.escape(folded)}{tail}")


class Rules:
    """A search's text rules, compiled once for the life of its poller."""

    def __init__(self, query: Query) -> None:
        self.query = query
        self._banned = [
            (word, pattern)
            for word in query.banned_keywords
            if (pattern := _word_pattern(word)) is not None
        ]
        # Each term is a list of alternatives, any one of which satisfies it. Must-include
        # words match word beginnings: someone who asks for "jean" wants the jeans too.
        self._include = [
            (term, patterns)
            for term in query.include_terms
            if (
                patterns := [p for alt in term.split("|") if (p := _word_pattern(alt, prefix=True))]
            )
        ]
        self._regex = re.compile(query.regex, TITLE_REGEX_FLAGS) if query.regex else None
        self._conditions = {fold(condition) for condition in query.conditions or []}

    def check(
        self,
        item: Item,
        *,
        blocked_sellers: frozenset[int] = frozenset(),
        rates: Mapping[str, Decimal] | None = None,
    ) -> Rejection | None:
        """Return why this listing should be skipped, or None if it passes the cheap rules.

        `rates` are euro exchange rates (see engine/rates.py), needed only by searches
        whose sites price in more than one currency.
        """
        return (
            _check_origin(item, blocked_sellers)
            or self._check_text(item)
            or _check_price(item, self.query, rates or {})
            or _check_margin(item, self.query)
            or self._check_condition(item)
        )

    def _check_text(self, item: Item) -> Rejection | None:
        text = fold(" ".join(filter(None, [item.title, item.brand])))
        for word, pattern in self._banned:
            if pattern.search(text):
                return Rejection("banned_keyword", f"title contains {word!r}")
        for term, alternatives in self._include:
            if not any(pattern.search(text) for pattern in alternatives):
                return Rejection("missing_keyword", f"title lacks {term!r}")
        if self._regex is not None and not self._regex.search(item.title):
            return Rejection("regex", f"title does not match {self.query.regex!r}")
        return None

    def _check_condition(self, item: Item) -> Rejection | None:
        # The new catalog often leaves condition out. Unknown is not a mismatch: the
        # condition is better asked of Vinted itself, through the search URL.
        if (
            self._conditions
            and item.condition is not None
            and fold(item.condition) not in self._conditions
        ):
            return Rejection("condition", f"condition {item.condition!r} not wanted")
        return None


def _check_origin(item: Item, blocked_sellers: frozenset[int]) -> Rejection | None:
    if item.promoted:
        # Boosted listings resurface old stock. They are not new, whatever the feed says.
        return Rejection("promoted", "listing is a paid bump")
    if item.seller_id is not None and item.seller_id in blocked_sellers:
        return Rejection(
            "blocked_seller", f"seller {item.seller_login or item.seller_id} is blocked"
        )
    return None


def _check_price(item: Item, query: Query, rates: Mapping[str, Decimal]) -> Rejection | None:
    """The price limits, which are in the search's own site's currency.

    A search on several sites sees other currencies too, and comparing the bare numbers
    let a 39 € listing under an 80 zł limit. Those are converted at the daily reference
    rate; without one the limit cannot be judged, and the listing is skipped saying so
    rather than let through on a comparison that means nothing.
    """
    if query.max_total_price is None and query.min_total_price is None:
        return None
    payable = item.total_price if item.total_price is not None else item.price
    if payable is None:
        return Rejection("no_price", "listing has no price to compare")
    own = site_currency(query.tld)
    currency = (item.currency or own).upper()
    shown = f"{payable} {currency}"
    if currency != own:
        converted = convert(payable, currency, own, rates)
        if converted is None:
            return Rejection(
                "no_exchange_rate",
                f"priced {shown}, and there is no {currency} to {own} exchange rate yet "
                f"to compare with this search's limits in {own}",
            )
        payable, shown = converted, f"{shown} (about {converted} {own})"
    if query.max_total_price is not None and payable > query.max_total_price:
        return Rejection(
            "over_budget",
            f"{shown} above limit {query.max_total_price} {own} (buyer protection included)",
        )
    if query.min_total_price is not None and payable < query.min_total_price:
        return Rejection("under_minimum", f"{shown} below minimum {query.min_total_price} {own}")
    return None


def _check_margin(item: Item, query: Query) -> Rejection | None:
    """Skip what would not leave enough after reselling.

    A margin that cannot be worked out (a listing in another site's currency) lets the
    listing through, like every other filter that cannot be judged.
    """
    if query.min_margin is None:
        return None
    margin = query.margin_on(item)
    if margin is None or margin >= query.min_margin:
        return None
    return Rejection(
        "low_margin",
        f"reselling at {query.resale_price} would leave about {margin} after fees and "
        f"postage; this search wants at least {query.min_margin}",
    )


def check(item: Item, query: Query) -> Rejection | None:
    """The cheap rules for one listing, compiling them on the spot. Pollers use `Rules`."""
    return Rules(query).check(item)


def matches(item: Item, query: Query) -> bool:
    return check(item, query) is None


def needs_lookup(item: Item, query: Query) -> bool:
    """Whether judging this listing's seller takes a member-page lookup.

    A country filter always does. The rating filters only do when the listing itself does
    not say — the old catalog carried ratings, the new one does not.
    """
    if query.countries:
        return True
    wants_rating = (
        query.seller_min_rating is not None
        or query.seller_min_reviews is not None
        or query.skip_unrated_sellers
    )
    return wants_rating and item.seller_rating is None and item.seller_feedback_count is None


def check_seller(item: Item, query: Query, profile: SellerProfile | None) -> Rejection | None:
    """Judge the seller, from the listing's own fields and a member-page profile if we have one.

    A missing profile means the lookup is unavailable, and a filter that cannot be judged
    lets the listing through: skipping everything because one input is unknown is how a
    search goes silent with no explanation.
    """
    return _check_country(query, profile) or _check_reputation(item, query, profile)


def _check_country(query: Query, profile: SellerProfile | None) -> Rejection | None:
    if not query.countries or profile is None:
        return None
    country = (profile.country_code or "").upper()
    if not country:
        return Rejection("seller_country", "seller's country is not public")
    if country not in query.countries:
        return Rejection("seller_country", f"seller is in {country}")
    return None


def _check_reputation(item: Item, query: Query, profile: SellerProfile | None) -> Rejection | None:
    rating = item.seller_rating
    if rating is None and profile is not None and profile.rating is not None:
        # Listings carry Vinted's 0..1 fraction; a member page reports stars out of five.
        rating = profile.rating / _STARS
    reviews = item.seller_feedback_count
    if reviews is None and profile is not None:
        reviews = profile.feedback_count
    if rating is None and reviews is None:
        return None

    if reviews == 0 or (reviews is None and not rating):
        return _check_unrated(query)

    if query.seller_min_reviews is not None and (reviews or 0) < query.seller_min_reviews:
        return Rejection("few_reviews", f"{reviews} reviews, want {query.seller_min_reviews}")
    if query.seller_min_rating is not None and rating is not None:
        stars = rating * _STARS
        if stars < query.seller_min_rating:
            return Rejection(
                "low_rating", f"rated {stars:.1f} stars, want {query.seller_min_rating:g}"
            )
    return None


def _check_unrated(query: Query) -> Rejection | None:
    """A new seller has no rating to compare, so only the filters about reviews apply."""
    if query.skip_unrated_sellers:
        return Rejection("unrated_seller", "seller has no reviews yet")
    if query.seller_min_reviews:
        return Rejection("few_reviews", "seller has no reviews yet")
    return None


def check_deal(item: Item, query: Query, typical: Decimal | None) -> Rejection | None:
    """For deal-only searches: is this far enough under what the search usually finds?"""
    if query.deal_only_pct is None:
        return None
    pct = deal_percent(item.total_price or item.price, typical)
    if pct is None:
        return Rejection("not_a_deal", "not enough history yet to know a typical price")
    if pct < query.deal_only_pct:
        distance = f"{pct}% under" if pct >= 0 else f"{-pct}% above"
        return Rejection(
            "not_a_deal",
            f"{distance} the typical {typical} {item.currency or ''}".rstrip()
            + f", want at least {query.deal_only_pct}% under",
        )
    return None

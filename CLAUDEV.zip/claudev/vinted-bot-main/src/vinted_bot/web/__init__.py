"""The optional web dashboard."""

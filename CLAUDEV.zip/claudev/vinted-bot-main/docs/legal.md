# Rules, risks, and other people's data

Not legal advice. This is what the project assumes and why, so you can decide for yourself.

## Vinted's terms

Vinted's terms of service prohibit automated access: bots, scrapers, crawlers, the usual
list. That is a contract between you and Vinted, not a law. Breaking it is not a crime; it
gives Vinted grounds to stop serving you.

In the EU, reading publicly available pages is not in itself unlawful. Courts in several
jurisdictions have reached similar conclusions about public data. What the terms give Vinted
is the right to block you and, if you have an account, to close it.

## What that means in practice

This tool reads public listing pages anonymously. It doesn't log in, so no credentials are
stored and there is no account attached for Vinted to restrict.

The realistic worst case is that your IP address stops being served, which is temporary and
reversible. That is a meaningfully different risk from tools that log in to buy automatically:
Vinted has been restricting accounts it suspects of automation, and an account restriction
costs you your purchase history, your listings and your reputation.

This is also why buying is not a feature here and will not become one.

## Being a reasonable guest

The defaults keep the load small even though checks are frequent:

- One check every 5 seconds per search by default, never more than one a second. Vinted's
  search takes 15 to 30 seconds to show a new upload, so going faster than that gains little.
- At most 8 searches a second leave the computer, all searches together; any more wait their
  turn. In November 2026 Vinted answered 12 a second from one address without complaint and
  started refusing at 20.
- One request per check for each country site the search covers. No walking through pages,
  no fetching every listing's detail page.
- A seller's public profile is read only for searches that filter on the seller (country,
  rating, reviews), only for listings that passed every other filter, and at most once a
  week per seller.
- Watched listings and sellers are re-read every half hour or quarter of an hour, a few
  requests a minute at most across all of them.
- Sessions are reused rather than re-established constantly.
- Backing off when told to, and honouring the wait Vinted asks for.

If you run many searches, raise the interval rather than adding parallelism. The point is to
be a slightly unusual visitor, not a load test.

## Other people's data

Listings contain personal data: seller usernames, profile links, sometimes a city, sometimes a
rating. Under the GDPR that makes you a controller of that data once you store it, even for
personal use. The personal-use exemption is narrower than people assume, and it does not
survive publishing or sharing.

How the project keeps that small:

- Only what a notification or a filter needs is stored: username, rating, number of reviews
  and country, not full profiles.
- Full API payloads are off by default (`KEEP_RAW_JSON=false`).
- Listings are deleted after thirty days, and the list of skipped listings after a week.
- Blocking a seller stores their username and your reason, on your machine only.
- Everything stays in a file on your machine. Nothing is sent anywhere except the
  notifications you configured.
- No seller profiling, no cross-referencing, no aggregate datasets.

If you change these (turning on raw payloads, extending retention, exporting your finds as
CSV or JSON) you are taking on more responsibility for that data. If you make anything public, you need a
lawful basis, and "it was already public" is not one.

Do not use this to build a dataset about individual sellers, to resell scraped data, or to
target anyone. That is a different activity from watching for a jacket in your size.

## Sharing what you find

Notifications are for you. Republishing listing photos or descriptions at scale runs into
copyright (the seller took those photos) as well as the concerns above. A link is fine. A
mirror is not.

## If Vinted asks you to stop

Then stop. This project has no interest in being adversarial with them; it exists because the
official notifications are slow, not because anyone wants a fight. If you receive a notice,
comply with it, and please open an issue so other people know.

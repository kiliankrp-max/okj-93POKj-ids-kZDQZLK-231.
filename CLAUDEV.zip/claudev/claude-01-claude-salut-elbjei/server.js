#!/usr/bin/env node
'use strict';
/*
 * Serveur local du tableau de bord.
 * - sert les fichiers de public/ et les photos de data/photos/
 * - GET/PUT /api/state      : données du tableau de bord (data/db.json, sauvegardes horodatées)
 * - GET/PUT /api/ai/config  : choix de l'IA et clés (data/config.json, jamais renvoyées en clair)
 * - POST /api/ai/run        : rédaction d'annonce / estimation de prix par l'IA
 * - POST /api/photos        : enregistre une photo (JPEG) et renvoie son adresse
 * - GET /api/fetch-meta     : lit le titre, le prix et l'image d'une page produit
 * Par défaut il n'écoute que sur 127.0.0.1 (ton ordinateur uniquement).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dns = require('dns').promises;
const net = require('net');
const ai = require('./ai');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const ROOT = path.join(__dirname, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB = path.join(DATA_DIR, 'db.json');
const CONFIG = path.join(DATA_DIR, 'config.json');
const BACKUPS = path.join(DATA_DIR, 'backups');
const PHOTOS = path.join(DATA_DIR, 'photos');
const MAX_STATE = 50 * 1024 * 1024;
const MAX_PHOTO = 15 * 1024 * 1024;
const MAX_AI = 40 * 1024 * 1024;
const BACKUP_EVERY_MS = 10 * 60 * 1000;
const BACKUP_KEEP = 30;

fs.mkdirSync(BACKUPS, { recursive: true });
fs.mkdirSync(PHOTOS, { recursive: true });

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
};

function send(res, code, body, type = 'application/json; charset=utf-8', extra = {}) {
  res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra });
  res.end(body);
}
const json = (res, code, obj) => send(res, code, JSON.stringify(obj));

function readBody(req, max) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > max) { reject(Object.assign(new Error('données trop volumineuses'), { status: 413 })); req.destroy(); }
      else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
async function readJSON(req, max) {
  if (!String(req.headers['content-type'] || '').startsWith('application/json')) throw Object.assign(new Error('JSON attendu'), { status: 415 });
  try { return JSON.parse(await readBody(req, max)); } catch (e) { if (e.status) throw e; throw Object.assign(new Error('JSON invalide'), { status: 400 }); }
}

/* ---------- données ---------- */
let lastBackup = 0;
function backupPrevious() {
  if (Date.now() - lastBackup < BACKUP_EVERY_MS || !fs.existsSync(DB)) return;
  lastBackup = Date.now();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  fs.copyFileSync(DB, path.join(BACKUPS, `db-${stamp}.json`));
  const files = fs.readdirSync(BACKUPS).filter(f => f.endsWith('.json')).sort();
  for (const f of files.slice(0, Math.max(0, files.length - BACKUP_KEEP))) fs.unlinkSync(path.join(BACKUPS, f));
}
function writeAtomic(file, text) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, text, { mode: 0o600 });
  fs.renameSync(tmp, file);
}
function loadConfig() { try { return JSON.parse(fs.readFileSync(CONFIG, 'utf8')); } catch (e) { return { provider: 'anthropic', keys: {}, models: {} }; } }

/* ---------- lecture d'une page produit (protégée contre l'accès au réseau local) ---------- */
function isPrivateIP(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const v = ip.toLowerCase();
  if (v.startsWith('::ffff:')) return isPrivateIP(v.slice(7));
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80');
}
async function safeFetch(url, redirects = 3) {
  const u = new URL(url);
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('adresse http(s) attendue');
  const addrs = await dns.lookup(u.hostname, { all: true });
  if (!addrs.length || addrs.some(a => isPrivateIP(a.address))) throw new Error('adresse non autorisée');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 9000);
  try {
    const r = await fetch(u, { redirect: 'manual', signal: ctrl.signal, headers: { 'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36', 'accept-language': 'fr-FR,fr;q=0.9' } });
    if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
      if (!redirects) throw new Error('trop de redirections');
      return safeFetch(new URL(r.headers.get('location'), u).toString(), redirects - 1);
    }
    if (!r.ok) throw new Error('la page a répondu ' + r.status);
    const reader = r.body.getReader();
    let html = '', total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.length;
      html += Buffer.from(value).toString('utf8');
      if (total > 3 * 1024 * 1024) { ctrl.abort(); break; }
    }
    return { html, finalUrl: u.toString() };
  } finally { clearTimeout(timer); }
}
function decodeEntities(s) {
  return String(s || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).trim();
}
function extractMeta(html, baseUrl) {
  const meta = name => {
    const re = new RegExp(`<meta[^>]+(?:property|name|itemprop)=["']${name}["'][^>]*>`, 'i');
    const tag = html.match(re);
    if (!tag) return '';
    const c = tag[0].match(/content=["']([^"']*)["']/i);
    return c ? decodeEntities(c[1]) : '';
  };
  let title = meta('og:title') || meta('twitter:title') || decodeEntities((html.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1]);
  let image = meta('og:image') || meta('twitter:image');
  let price = meta('product:price:amount') || meta('og:price:amount') || meta('price');
  let currency = meta('product:price:currency') || meta('og:price:currency') || meta('priceCurrency');
  for (const m of html.matchAll(/<script[^>]+application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const data = JSON.parse(m[1]);
      const list = [].concat(data['@graph'] || data);
      const prod = list.find(x => x && /Product/i.test([].concat(x['@type']).join(' ')));
      if (!prod) continue;
      title = title || prod.name;
      image = image || [].concat(prod.image || [])[0];
      const offer = [].concat(prod.offers || [])[0] || {};
      price = price || offer.price || offer.lowPrice;
      currency = currency || offer.priceCurrency;
    } catch (e) { /* bloc illisible */ }
  }
  if (image && typeof image === 'object') image = image.url;
  if (image) { try { image = new URL(image, baseUrl).toString(); } catch (e) { image = ''; } }
  const p = parseFloat(String(price || '').replace(',', '.'));
  return { title: title || '', image: image || '', price: isFinite(p) ? p : null, currency: currency || '' };
}

/* ---------- scraping Vinted (svc-catalogue, session bootstrappée) ---------- */

// User agents extraits de l'agents.json du vinted-bot (poids réels Chrome 124+)
const _UA_POOL = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
];

/* ---------- compte acheteur authentifié ---------- */
let _buyerAuth = null; // { email, accessToken, refreshToken, expiresAt }

function _buyerHeaders(token) {
  return {
    'authorization': `Bearer ${token}`,
    'content-type': 'application/json',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'fr-FR,fr;q=0.9',
    'origin': 'https://www.vinted.fr',
    'referer': 'https://www.vinted.fr/',
    'user-agent': _UA_POOL[0],
    'x-next-app': 'marketplace-web',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
  };
}

async function _vintedOAuth(body) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12000);
  try {
    const r = await fetch('https://www.vinted.fr/oauth/token', {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
        'accept': 'application/json',
        'user-agent': _UA_POOL[0],
        'origin': 'https://www.vinted.fr',
        'referer': 'https://www.vinted.fr/',
        'x-next-app': 'marketplace-web',
      },
      body: new URLSearchParams(body).toString(),
    });
    clearTimeout(t);
    const data = await r.json();
    if (!r.ok) throw new Error(data.error_description || data.message || `OAuth erreur ${r.status}`);
    if (!data.access_token) throw new Error('Pas de token dans la réponse Vinted');
    return data;
  } catch (e) { clearTimeout(t); throw e; }
}

async function _getBuyerToken() {
  if (!_buyerAuth) throw new Error('Non connecté');
  if (Date.now() < _buyerAuth.expiresAt - 60000) return _buyerAuth.accessToken;
  const data = await _vintedOAuth({ grant_type: 'refresh_token', refresh_token: _buyerAuth.refreshToken, client_id: 'web' });
  _buyerAuth.accessToken = data.access_token;
  _buyerAuth.expiresAt = Date.now() + (data.expires_in || 3600) * 1000;
  if (data.refresh_token) _buyerAuth.refreshToken = data.refresh_token;
  return _buyerAuth.accessToken;
}

// Session anonyme en cache (access_token_web + anon_id + locale)
let _vintedSession = null;
let _vintedSessionAt = 0;
const _SESSION_TTL = 50 * 60 * 1000; // 50 min, Vinted invalide après ~60min

async function getVintedSession() {
  if (_vintedSession && Date.now() - _vintedSessionAt < _SESSION_TTL) return _vintedSession;
  const ua = _UA_POOL[Math.floor(Math.random() * _UA_POOL.length)];
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 12000);
    const r = await fetch('https://www.vinted.fr/', {
      signal: ctrl.signal,
      headers: {
        'user-agent': ua,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
        'accept-encoding': 'gzip, deflate, br',
        'dnt': '1',
        'upgrade-insecure-requests': '1',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
      },
      redirect: 'follow',
    });
    clearTimeout(t);
    const setCookies = [];
    r.headers.forEach((v, k) => { if (k === 'set-cookie') setCookies.push(v); });
    const cookies = {};
    for (const c of setCookies) {
      const m = /^([^=]+)=([^;]*)/.exec(c);
      if (m) cookies[m[1].trim()] = m[2].trim();
    }
    if (!cookies['access_token_web']) return null;
    _vintedSession = { ua, cookies };
    _vintedSessionAt = Date.now();
    return _vintedSession;
  } catch (e) { return null; }
}

function parseSvcItems(payload) {
  // svc-catalogue renvoie { items: [...] } avec photo (objet), user, price (objet)
  const list = (payload && payload.items) || [];
  return list.map(item => {
    const priceObj = item.price;
    const price = priceObj && (priceObj.amount != null ? priceObj.amount : priceObj);
    const photo = item.photo || (item.photos && item.photos[0]) || {};
    const image = photo.full_size_url || photo.url || (photo.high_resolution && photo.high_resolution.url) || '';
    const user = item.user || {};
    const rawUrl = item.url || item.path || '';
    const url = rawUrl.startsWith('http') ? rawUrl : `https://www.vinted.fr${rawUrl}`;
    // brand et taille depuis item_box (svc-catalogue ne retourne pas brand_title directement)
    const box = item.item_box || {};
    const boxFirst = String(box.first_line || '').trim();
    const title = String(item.title || '').slice(0, 80);
    // first_line = brand quand présent, sinon = titre. Si différents → c'est la marque.
    const brand = (boxFirst && boxFirst !== title) ? boxFirst : '';
    const boxSecond = String(box.second_line || '').trim();
    const sizeMatch = boxSecond.match(/^([^\s·]+)/);
    const size = sizeMatch ? sizeMatch[1] : '';
    // condition depuis second_line : "Taille M · Très bon état"
    const condRaw = boxSecond.toLowerCase();
    const condition = condRaw.includes('neuf avec') ? 'nwt'
      : condRaw.includes('neuf') ? 'new'
      : condRaw.includes('très bon') ? 'vgood'
      : condRaw.includes('bon') ? 'good'
      : condRaw.includes('satisfaisant') ? 'fair'
      : '';
    // brand fallback: chercher dans le titre si first_line inutilisable
    let resolvedBrand = brand;
    if (!resolvedBrand) {
      const tl = title.toLowerCase();
      for (const tier of _BRAND_TIERS) {
        for (const name of tier.brands) {
          if (tl.startsWith(name) || tl.includes(` ${name} `) || tl.includes(` ${name}`) || tl.startsWith(name + ' ')) {
            resolvedBrand = name; break;
          }
        }
        if (resolvedBrand) break;
      }
    }
    // Détection revendeur : business officiel, beaucoup d'articles, ou signaux dans le login
    const login = String(user.login || '').toLowerCase();
    const sellerResellSignal = /shop|store|boutique|resell|friperie|stock|luxe/.test(login);
    const isBusiness = !!(
      user.is_business || user.business || user.pro ||
      (user.item_count != null && user.item_count > 30) ||
      sellerResellSignal
    );
    // Détection boost Vinted
    const isPromoted = !!(item.is_promoted || item.promoted || item.is_featured || item.featured);
    // Détection photo IA (feature Vinted "AI photo")
    const csrc = String(item.content_source || '').toLowerCase();
    const photoObj = item.photo || (item.photos && item.photos[0]) || {};
    const isAiPhoto = csrc.includes('ai') || !!photoObj.is_ai_generated || !!photoObj.ai_generated;
    const country = String(user.country_title || user.country || '').trim();
    return {
      title,
      price: parseFloat(price) || 0,
      image,
      url,
      seller: user.login || '',
      sellerCount: user.item_count || 0,
      brand: resolvedBrand,
      size,
      condition,
      isBusiness,
      isPromoted,
      isAiPhoto,
      country,
      // created_at_ts = timestamp UNIX de publication Vinted (secondes), fallback = maintenant
      ts: item.created_at_ts ? item.created_at_ts * 1000 : Date.now(),
    };
  }).filter(i => i.price > 0 && i.title);
}

async function scrapeVinted(query, filters = {}) {
  const { priceTo, priceFrom, statusIds = [], colorIds = [], catalogIds = [], countryIds = [], order = 'newest_first' } = filters;
  const session = await getVintedSession();
  if (session) {
    try {
      const now = Math.floor(Date.now() / 1000);
      const pad = ' '.repeat(now % 180 + 1);
      const params = new URLSearchParams({
        search_text: query + pad,
        per_page: '96',
        order: order,
        time: String(now - Math.floor(Math.random() * 180)),
      });
      if (priceTo) params.set('price_to', String(priceTo));
      if (priceFrom) params.set('price_from', String(priceFrom));
      // Vinted svc-catalogue uses attribute_ids[<name>] since Sep 2026
      if (statusIds.length) params.set('attribute_ids[status]', statusIds.join(','));
      if (colorIds.length) params.set('attribute_ids[color]', colorIds.join(','));
      if (catalogIds.length) params.set('attribute_ids[catalog]', catalogIds.join(','));
      if (countryIds.length) params.set('country_ids[]', countryIds.join(','));
      const cookieHeader = Object.entries(session.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
      const locale = session.cookies['anonymous-iso-locale'] || 'fr-FR';
      const anonId = session.cookies['anon_id'] || '';
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 10000);
      const r = await fetch(`https://api.vinted.fr/svc-catalogue/items?${params}`, {
        signal: ctrl.signal,
        headers: {
          'user-agent': session.ua,
          'accept': 'application/json, text/plain, */*',
          'accept-language': 'fr-FR,fr;q=0.9',
          'accept-encoding': 'gzip, deflate, br',
          'origin': 'https://www.vinted.fr',
          'referer': 'https://www.vinted.fr/',
          'locale': locale,
          'platform': 'web',
          'x-next-app': 'marketplace-web',
          ...(anonId ? { 'x-anon-id': anonId } : {}),
          'dnt': '1',
          'sec-fetch-dest': 'empty',
          'sec-fetch-mode': 'cors',
          'sec-fetch-site': 'same-site',
          'cookie': cookieHeader,
        },
      });
      clearTimeout(t);
      if (r.ok) {
        const data = await r.json();

        const items = parseSvcItems(data);
        if (items.length) return items;
      } else if (r.status === 401 || r.status === 403) {
        // Session expirée, forcer le renouvellement
        _vintedSession = null;
      }
    } catch (e) { /* fallback */ }
  }

  // Fallback __NEXT_DATA__ (page HTML)
  try {
    const params = new URLSearchParams({ search_text: query, order: order || 'newest_first' });
    if (priceTo) params.set('price_to', String(priceTo));
    if (priceFrom) params.set('price_from', String(priceFrom));
    const { html } = await safeFetch(`https://www.vinted.fr/catalog?${params}`);
    const m = /<script id="__NEXT_DATA__" type="application\/json"[^>]*>([\s\S]*?)<\/script>/.exec(html);
    if (!m) return [];
    const data = JSON.parse(m[1]);
    const pp = data && data.props && data.props.pageProps;
    const list = (pp && (pp.items || (pp.catalogItems && pp.catalogItems.items))) || [];
    return parseSvcItems({ items: list });
  } catch (e) { return []; }
}

async function scrapeVintedCheap() {
  const queries = ['robe femme', 'pull oversize', 'jean vintage'];
  const results = [];
  for (const q of queries.slice(0, 2)) {
    results.push(...await scrapeVinted(q, { priceTo: 18 }));
    await new Promise(r => setTimeout(r, 300));
  }
  return results.slice(0, 20);
}

const VALID_ORDERS = new Set(['newest_first', 'price_low_to_high', 'price_high_to_low', 'relevance', 'popularity']);

// Prix "bon deal" max par tier de marque (Vinted.fr, vêtements/accessoires)
const _BRAND_TIERS = [
  { maxGood: 120, brands: ['gucci','louis vuitton','prada','balenciaga','off-white','dior','saint laurent','ysl','versace','givenchy','fendi','celine','bottega veneta','rick owens','margiela','maison margiela','acne studios','kenzo','isabel marant','jacquemus','ami paris','a.p.c','apc'] },
  { maxGood: 55,  brands: ['supreme','palace','bape','a bathing ape','stussy','kith','needles','kapital','undercover','raf simons','helmut lang','wtaps','neighborhood','carhartt wip'] },
  { maxGood: 30,  brands: ['stone island','cp company','moncler','canada goose','north face','the north face','arc\'teryx','arcteryx','sandro','maje','barbour','hackett','scuffer','cold culture'] },
  { maxGood: 18,  brands: ['ralph lauren','polo ralph lauren','lacoste','tommy hilfiger','fred perry','levi\'s','levis','wrangler','dickies','ben sherman','farah','carhartt','timberland','lonsdale','sergio tacchini'] },
  { maxGood: 10,  brands: ['nike','adidas','new balance','puma','reebok','under armour','champion','fila','ellesse','umbro','kappa','mizuno','asics','columbia'] },
  { maxGood: 6,   brands: ['vans','converse','dc','element','quiksilver','billabong','volcom','obey','huf','thrasher','primitive','santa cruz','zara','h&m','uniqlo'] },
];

function _getBrandMaxGood(brand) {
  if (!brand) return null;
  const b = brand.toLowerCase();
  for (const tier of _BRAND_TIERS) {
    for (const name of tier.brands) {
      if (b === name || b.includes(name)) return tier.maxGood;
    }
  }
  return null;
}

// Rolling price memory per query
const _priceHistory = new Map();

const _COND_MULT = { nwt: 1.65, new: 1.4, vgood: 1.1, good: 1.0, fair: 0.75 };

// Size demand on Vinted.fr (S/M most liquid, XL+ harder to sell)
const _SIZE_MULT = {
  'xs':0.82,'s':0.98,'m':1.05,'l':1.0,'xl':0.84,'xxl':0.70,'xxxl':0.55,
  '34':0.88,'36':0.95,'38':1.05,'40':1.05,'42':0.95,'44':0.85,'46':0.72,'48':0.60,
  'one size':1.0,'unique':1.0,'tu':1.0,
};

// Item type rules — keyword → { mult, marketWord (appended to market query) }
const _TYPE_RULES = [
  { m:1.65, q:'jacket',   kw:['jacket','veste','blouson','bomber','parka','manteau','coat','windbreaker','coupe-vent','anorak','trench'] },
  { m:1.35, q:'hoodie',   kw:['hoodie','sweatshirt','sweat','crewneck','crew neck','zip-up','zipper','fleece'] },
  { m:1.20, q:'pull',     kw:['pullover','pull','knitwear','knit','cardigan','sweater'] },
  { m:1.10, q:'shirt',    kw:['shirt','chemise','flannel','oxford','button','overshirt'] },
  { m:1.00, q:'t-shirt',  kw:['tee','t-shirt','tshirt','tee-shirt','logo tee','graphic','box logo'] },
  { m:1.15, q:'pantalon', kw:['pant','pantalon','cargo','chino','trouser','jean','denim','short','bermuda'] },
  { m:0.88, q:'casquette',kw:['cap','casquette','hat','bonnet','beanie','bucket hat','snapback','fitted'] },
  { m:1.30, q:'sac',      kw:['bag','sac','backpack','tote','sacoche','sling'] },
  { m:0.80, q:'accessoire',kw:['sock','chaussette','belt','ceinture','lanyard','keychain','porte-cle'] },
];

function _getSizeMult(size) {
  if (!size) return 1.0;
  return _SIZE_MULT[size.toLowerCase().trim()] || 1.0;
}

function _getTypeInfo(title) {
  if (!title) return { m: 1.0, q: '' };
  const t = title.toLowerCase();
  for (const rule of _TYPE_RULES) {
    if (rule.kw.some(k => t.includes(k))) return { m: rule.m, q: rule.q };
  }
  return { m: 1.0, q: '' };
}

// Market price cache keyed by "brand|typeword" for per-category accuracy
const _marketCache = new Map();
const _marketQueue = new Map(); // key -> query string
let _marketBusy = false;
const MARKET_TTL = 90 * 60 * 1000;

function _marketCached(key) {
  const e = _marketCache.get(key);
  return (e && Date.now() - e.fetchedAt < MARKET_TTL) ? e.p65 : null;
}

function _marketEnqueue(brand, typeWord) {
  if (!brand) return;
  const key = brand.toLowerCase() + (typeWord ? '|' + typeWord : '');
  if (_marketCached(key) !== null) return;
  const query = typeWord ? `${brand} ${typeWord}` : brand;
  _marketQueue.set(key, query);
  if (!_marketBusy) _marketDrain();
}

async function _marketDrain() {
  _marketBusy = true;
  while (_marketQueue.size > 0) {
    const [[key, query]] = _marketQueue;
    _marketQueue.delete(key);
    try {
      const items = await scrapeVinted(query, { order: 'price_low_to_high' });
      const prices = items.map(i => i.price).filter(p => p > 2).sort((a, b) => a - b);
      if (prices.length >= 5) {
        const p65 = prices[Math.floor(prices.length * 0.65)];
        _marketCache.set(key, { p65, fetchedAt: Date.now() });
      }
    } catch {}
    await new Promise(r => setTimeout(r, 1500));
  }
  _marketBusy = false;
}

function batchRevente(items, q) {
  if (!_priceHistory.has(q)) _priceHistory.set(q, []);
  const history = _priceHistory.get(q);
  items.forEach(i => { if (i.price > 0) history.push(i.price); });
  if (history.length > 300) history.splice(0, history.length - 300);

  const sorted = history.length >= 6 ? [...history].sort((a, b) => a - b) : null;
  const median = sorted ? sorted[Math.floor(sorted.length * 0.5)] : null;

  return items.map(i => {
    const e = { ...i, _q: q };
    if (i.price <= 0) return e;

    const condMult = _COND_MULT[i.condition] || 1.0;
    const sizeMult = _getSizeMult(i.size);
    const { m: typeMult, q: typeWord } = _getTypeInfo(i.title);

    // Market key: brand + type word (e.g. "carhartt|t-shirt") for per-category accuracy
    const mKey = (i.brand || '').toLowerCase() + (typeWord ? '|' + typeWord : '');
    const marketBase = mKey ? _marketCached(mKey) : null;
    _marketEnqueue(i.brand, typeWord);

    // Static tier as floor/sanity cap
    const staticBase = _getBrandMaxGood(i.brand);

    // Prefer market data; cap at 1.5× static to stay grounded; market is already type-specific so skip typeMult there
    let base = null, source = null;
    if (marketBase !== null) {
      base = staticBase !== null ? Math.min(marketBase, staticBase * 1.5) : marketBase;
      source = 'market';
    } else if (staticBase !== null) {
      base = staticBase;
      source = 'brand';
    }

    if (base !== null) {
      const tM = source === 'brand' ? typeMult : 1.0;
      const estimate = Math.round(base * condMult * sizeMult * tM);
      if (i.price < estimate) {
        e._reventeEstimate = estimate;
        e._profitPct = Math.round((estimate / i.price - 1) * 100);
        e._dealSource = source;
        e._tier = e._profitPct >= 100 ? 'fire' : e._profitPct >= 40 ? 'hot' : 'ok';
      }
    } else if (median !== null && i.price < median * 0.72) {
      const estimate = Math.round(median * condMult * sizeMult * typeMult * 10) / 10;
      e._reventeEstimate = estimate;
      e._profitPct = Math.round((estimate / i.price - 1) * 100);
      e._dealSource = 'median';
      e._tier = e._profitPct >= 100 ? 'fire' : e._profitPct >= 40 ? 'hot' : 'ok';
    }
    return e;
  });
}

async function snipeSearch(queries, filters = {}) {
  const { size = '', clothing = '', particularOnly = false, countryIds = [] } = filters;
  const qs = queries.filter(x => x && typeof x === 'string').slice(0, 8);
  const fetches = qs.map((q, i) => new Promise(r => setTimeout(async () => {
    let query = q.trim();
    if (size) query = `${query} ${size}`;
    if (clothing && !query.toLowerCase().includes(clothing.toLowerCase())) query = `${query} ${clothing}`;
    try { r(batchRevente(await scrapeVinted(query, { ...filters, countryIds }), q.trim())); }
    catch { r([]); }
  }, i * 80)));
  const batches = await Promise.all(fetches);
  const seen = new Set();
  const results = [];
  for (const items of batches) {
    for (const item of items) {
      const key = item.url || (item.title + '|' + item.price);
      if (seen.has(key)) continue;
      seen.add(key);
      if (item.isPromoted) continue;
      if (item.isAiPhoto) continue;
      if (particularOnly && item.isBusiness) continue;
      results.push(item);
    }
  }
  return results;
}

/* ---------- routes ---------- */
function hostAllowed(req) {
  if (HOST !== '127.0.0.1' && HOST !== 'localhost') return true;
  const h = String(req.headers.host || '').replace(/:\d+$/, '');
  return h === 'localhost' || h === '127.0.0.1' || h === '[::1]';
}

async function handle(req, res) {
  if (!hostAllowed(req)) return json(res, 403, { error: 'hôte non autorisé' });
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  if (p === '/api/health') return json(res, 200, { ok: true });

  if (p === '/api/state') {
    if (req.method === 'GET') {
      let txt = 'null';
      try { txt = fs.readFileSync(DB, 'utf8'); } catch (e) { /* pas encore de données */ }
      return send(res, 200, txt);
    }
    if (req.method === 'PUT') {
      const obj = await readJSON(req, MAX_STATE);
      if (!obj || !Array.isArray(obj.accounts) || !Array.isArray(obj.sales)) return json(res, 400, { error: 'format invalide' });
      if (obj.proposals !== undefined && !Array.isArray(obj.proposals)) return json(res, 400, { error: 'format invalide (proposals)' });
      backupPrevious();
      writeAtomic(DB, JSON.stringify(obj));
      return json(res, 200, { ok: true });
    }
    return json(res, 405, { error: 'méthode non autorisée' });
  }

  if (p === '/api/ai/config') {
    if (req.method === 'GET') return json(res, 200, ai.publicConfig(loadConfig()));
    if (req.method === 'PUT') {
      const body = await readJSON(req, 64 * 1024);
      const cfg = loadConfig();
      cfg.keys = cfg.keys || {}; cfg.models = cfg.models || {};
      if (['anthropic', 'openai', 'gemini'].includes(body.provider)) cfg.provider = body.provider;
      for (const prov of ['anthropic', 'openai', 'gemini']) {
        if (body.keys && typeof body.keys[prov] === 'string') {
          const k = body.keys[prov].trim();
          if (k === '-') delete cfg.keys[prov];      // « - » efface la clé
          else if (k) cfg.keys[prov] = k;
        }
        if (body.models && typeof body.models[prov] === 'string') cfg.models[prov] = body.models[prov].trim();
      }
      writeAtomic(CONFIG, JSON.stringify(cfg, null, 1));
      return json(res, 200, ai.publicConfig(cfg));
    }
    return json(res, 405, { error: 'méthode non autorisée' });
  }

  if (p === '/api/ai/run' && req.method === 'POST') {
    const body = await readJSON(req, MAX_AI);
    try { return json(res, 200, await ai.run(loadConfig(), body.task, body.input || {})); }
    catch (e) { return json(res, 502, { error: e.message }); }
  }

  if (p === '/api/snipe/search' && req.method === 'POST') {
    const body = await readJSON(req, 64 * 1024);
    const queries = Array.isArray(body.queries) ? body.queries : [];
    if (!queries.filter(q => q).length) return json(res, 400, { error: 'queries requis' });
    const toNum = (v, min = 0) => { const n = Number(v); return isFinite(n) && n > min ? n : null; };
    const filters = {
      priceTo: toNum(body.maxPrice),
      priceFrom: toNum(body.priceFrom),
      order: VALID_ORDERS.has(body.order) ? body.order : 'newest_first',
      size: typeof body.size === 'string' ? body.size.trim().slice(0, 20) : '',
      statusIds: Array.isArray(body.statusIds) ? body.statusIds.map(Number).filter(n => n > 0) : [],
      colorIds: Array.isArray(body.colorIds) ? body.colorIds.map(Number).filter(n => n > 0) : [],
      catalogIds: Array.isArray(body.catalogIds) ? body.catalogIds.map(Number).filter(n => n > 0) : [],
      countryIds: Array.isArray(body.countryIds) ? body.countryIds.map(Number).filter(n => n > 0) : [],
    };
    try {
      const items = await snipeSearch(queries, filters);
      return json(res, 200, { items, ts: Date.now() });
    } catch (e) { return json(res, 502, { error: e.message }); }
  }


  if (p === '/api/propositions/scan' && req.method === 'POST') {
    const body = await readJSON(req, 64 * 1024);
    const type = ['trends', 'arbitrage', 'both'].includes(body.type) ? body.type : 'both';
    let cheapItems = [];
    if (type !== 'trends') {
      cheapItems = await scrapeVintedCheap();
    }
    try {
      const result = await ai.scan(loadConfig(), { type, cheapItems });
      const allItems = [...(result.trends || []), ...(result.arbitrage || [])];
      for (const item of allItems) {
        const kw = item.keywords || item.title;
        item.sourceUrl = `https://www.vinted.fr/catalog?search_text=${encodeURIComponent(kw)}&order=price_low_to_high`;
        item.sourceSite = 'vinted';
        const hits = await scrapeVinted(kw);
        const h = hits.find(x => x.image) || hits[0];
        if (h && h.image) {
          item.sourceImage = h.image;
          if (h.url) item.sourceUrl = h.url;
          item.sourceSeller = h.seller;
          item.sourcePrice = h.price;
        } else {
          const q = encodeURIComponent((item.keywords || item.title).split(' ').slice(0, 3).join(' '));
          const seed = Buffer.from(item.title).toString('base64').slice(0, 8);
          item.sourceImage = `https://picsum.photos/seed/${seed}/300/400`;
        }
        await new Promise(r => setTimeout(r, 250));
      }
      return json(res, 200, result);
    } catch (e) { return json(res, 502, { error: e.message }); }
  }

  if (p === '/api/propositions/images' && req.method === 'POST') {
    const body = await readJSON(req, 64 * 1024);
    if (!body.prompt || typeof body.prompt !== 'string') return json(res, 400, { error: 'prompt manquant' });
    let dataUrls;
    try { dataUrls = await ai.generateImages(loadConfig(), body.prompt.slice(0, 500)); }
    catch (e) { return json(res, 502, { error: e.message }); }
    const urls = [];
    for (const dataUrl of dataUrls) {
      const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
      if (!m) continue;
      const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
      const id = crypto.randomBytes(12).toString('hex');
      fs.writeFileSync(path.join(PHOTOS, id + '.' + ext), Buffer.from(m[2], 'base64'));
      urls.push(`photos/${id}.${ext}`);
    }
    return json(res, 200, { urls });
  }

  if (p === '/api/photos' && req.method === 'POST') {
    const body = await readJSON(req, MAX_PHOTO);
    const m = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(String(body.dataUrl || ''));
    if (!m) return json(res, 400, { error: 'photo JPEG attendue' });
    const id = crypto.randomBytes(12).toString('hex');
    fs.writeFileSync(path.join(PHOTOS, id + '.jpg'), Buffer.from(m[1], 'base64'));
    return json(res, 200, { url: `photos/${id}.jpg`, id });
  }

  if (p === '/api/fetch-meta' && req.method === 'GET') {
    try {
      const { html, finalUrl } = await safeFetch(url.searchParams.get('url') || '');
      return json(res, 200, { ...extractMeta(html, finalUrl), url: finalUrl });
    } catch (e) { return json(res, 502, { error: 'Lecture de la page impossible : ' + e.message }); }
  }

  if (p.startsWith('/photos/')) {
    const id = p.slice(8);
    if (!/^[a-f0-9]{24}\.jpg$/.test(id)) return send(res, 404, 'introuvable', 'text/plain; charset=utf-8');
    return fs.readFile(path.join(PHOTOS, id), (err, buf) => err ? send(res, 404, 'introuvable', 'text/plain; charset=utf-8') : send(res, 200, buf, 'image/jpeg', { 'cache-control': 'max-age=31536000, immutable' }));
  }

  if (p === '/api/buyer/login' && req.method === 'POST') {
    const { email, password } = await readJSON(req, 4096);
    if (!email || !password) return json(res, 400, { error: 'email et password requis' });
    try {
      const data = await _vintedOAuth({ grant_type: 'password', username: email, password, client_id: 'web', scope: 'user' });
      _buyerAuth = { email, accessToken: data.access_token, refreshToken: data.refresh_token, expiresAt: Date.now() + (data.expires_in || 3600) * 1000 };
      return json(res, 200, { ok: true, email, expiresAt: _buyerAuth.expiresAt });
    } catch (e) { return json(res, 401, { error: e.message }); }
  }

  if (p === '/api/buyer/status' && req.method === 'GET') {
    if (!_buyerAuth) return json(res, 200, { loggedIn: false });
    return json(res, 200, { loggedIn: true, email: _buyerAuth.email, expiresAt: _buyerAuth.expiresAt });
  }

  if (p === '/api/ext-path' && req.method === 'GET') {
    return json(res, 200, { path: require('path').join(__dirname, 'vinted-token-ext') });
  }

  if (p === '/api/buyer/logout' && req.method === 'POST') {
    _buyerAuth = null;
    return json(res, 200, { ok: true });
  }

  if (p === '/api/buyer/capture' && req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST', 'Access-Control-Allow-Headers': 'content-type' });
    res.end(); return;
  }

  if (p === '/api/buyer/capture' && req.method === 'POST') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const { token } = await readJSON(req, 8192);
    if (!token) return json(res, 400, { error: 'token manquant' });
    try {
      const payload = JSON.parse(Buffer.from(token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString());
      const expiresAt = payload.exp ? payload.exp * 1000 : Date.now() + 3600000;
      const email = payload.email || payload.user_id || 'compte Vinted';
      _buyerAuth = { email, accessToken: token, refreshToken: null, expiresAt };
      return json(res, 200, { ok: true, email, expiresAt });
    } catch { return json(res, 400, { error: 'JWT invalide' }); }
  }

  if (p === '/api/buyer/token' && req.method === 'POST') {
    const { accessToken } = await readJSON(req, 8192);
    if (!accessToken) return json(res, 400, { error: 'accessToken requis' });
    try {
      const payload = JSON.parse(Buffer.from(accessToken.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString());
      const expiresAt = payload.exp ? payload.exp * 1000 : Date.now() + 3600000;
      const email = payload.email || payload.user_id || 'compte social';
      _buyerAuth = { email, accessToken, refreshToken: null, expiresAt };
      return json(res, 200, { ok: true, email, expiresAt });
    } catch { return json(res, 400, { error: 'Token JWT invalide' }); }
  }

  if (p === '/api/buyer/init' && req.method === 'POST') {
    const { itemId } = await readJSON(req, 4096);
    if (!itemId) return json(res, 400, { error: 'itemId requis' });
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 10000);
    try {
      const token = await _getBuyerToken();
      const r = await fetch('https://www.vinted.fr/api/v2/transactions', {
        method: 'POST', signal: ctrl.signal,
        headers: _buyerHeaders(token),
        body: JSON.stringify({ transaction: { item_id: Number(itemId) } }),
      });
      clearTimeout(t);
      const data = await r.json();
      if (!r.ok) return json(res, r.status, { error: data.message || `Vinted erreur ${r.status}` });
      const tx = data.transaction || data;
      const purchaseId = tx.purchase_id || tx.purchaseId;
      const orderId = tx.id;
      if (!purchaseId || !orderId) return json(res, 502, { error: 'Réponse Vinted inattendue', raw: data });
      return json(res, 200, { checkoutUrl: `https://www.vinted.fr/checkout?purchase_id=${purchaseId}&order_id=${orderId}&order_type=transaction` });
    } catch (e) { clearTimeout(t); return json(res, e.message === 'Non connecté' ? 401 : 502, { error: e.message }); }
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'méthode non autorisée' });
  let rel;
  try { rel = decodeURIComponent(p); } catch (e) { return send(res, 400, 'URL invalide', 'text/plain; charset=utf-8'); }
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep)) return send(res, 403, 'interdit', 'text/plain; charset=utf-8');
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, 'introuvable', 'text/plain; charset=utf-8');
    send(res, 200, buf, TYPES[path.extname(file)] || 'application/octet-stream');
  });
}

const server = http.createServer((req, res) => {
  handle(req, res).catch(e => { if (!res.headersSent) json(res, e.status || 500, { error: e.message || 'erreur serveur' }); });
});
server.listen(PORT, HOST, () => {
  const shown = HOST === '0.0.0.0' ? 'localhost' : HOST;
  console.log(`Tableau de bord Vinted : http://${shown}:${PORT}`);
  console.log(`Données : ${DATA_DIR}`);
});

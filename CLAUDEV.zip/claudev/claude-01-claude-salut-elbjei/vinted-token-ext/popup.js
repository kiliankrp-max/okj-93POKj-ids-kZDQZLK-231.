const btn = document.getElementById('btn');
const status = document.getElementById('status');
const portInput = document.getElementById('port');

chrome.storage.local.get('port', d => { if (d.port) portInput.value = d.port; });

btn.addEventListener('click', async () => {
  const port = parseInt(portInput.value) || 3000;
  chrome.storage.local.set({ port });
  btn.disabled = true;
  status.textContent = 'Lecture du cookie…';
  status.style.color = '#a1a1aa';

  chrome.cookies.get({ url: 'https://www.vinted.fr', name: 'access_token_web' }, async cookie => {
    if (!cookie || !cookie.value) {
      status.textContent = 'Pas de token — connecte-toi à Vinted.fr d\'abord.';
      status.style.color = '#f87171';
      btn.disabled = false;
      return;
    }
    try {
      const r = await fetch(`http://localhost:${port}/api/buyer/capture`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ token: cookie.value }),
      });
      const d = await r.json();
      if (d.ok) {
        status.textContent = `Connecté — ${d.email}`;
        status.style.color = '#34d399';
      } else {
        status.textContent = 'Erreur : ' + (d.error || 'inconnu');
        status.style.color = '#f87171';
      }
    } catch {
      status.textContent = `Serveur non disponible (port ${port}) — lance node server.js`;
      status.style.color = '#f87171';
    }
    btn.disabled = false;
  });
});
